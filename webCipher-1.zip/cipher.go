package main

import(
				"net/http"
				"html/template"
				"fmt"
				"log"
				"strconv"
)


func Cipher(password string, shift int,flag string)string{
				fmt.Println("ciphing1: ",password)
				cipher := ""
				for _,x := range(password){
								if(flag=="/decrypt"){
							fmt.Println(int(x),x)
								ascii :=  int(x)+shift
							fmt.Println("ascii: ",ascii)
								if ascii>122{
												ascii = ascii-122
												fmt.Println("ascii2:",ascii	)
												ascii= ascii+96
												fmt.Println("ascii3:", ascii)
								}
								cipher+=string(ascii)
								}else{
												fmt.Println("encrypt")
										ascii := int(x)-shift
										if ascii<97{
												ascii=97-ascii
												ascii = 123-ascii
											}
											cipher+=string(ascii)
									}
					}
				fmt.Println("ciphing2: ",cipher)
				return cipher
}

func errEx(err error){
				if err != nil{
								log.Fatal(err)
				}
}

type Data struct{
				Password string
				Shift int
				Method string
}


func Handler(writer http.ResponseWriter, request *http.Request,cipher[] string,){
				shiftVal := request.FormValue("shift")
				if shiftVal ==""{
								shiftVal ="0"
				}
				shift, err0 :=strconv.Atoi(shiftVal)
				if err0 !=nil{
								msg:="ERROR:BAD VALUE 'value shift='\nusage:http://localhost:5000/?password=abc&shift=10" 
									_, err2 := writer.Write([]byte(msg))
									errEx(err2)

				}else{
				errEx(err0)
				fmt.Println("passs..........")
				html, err1 := template.ParseFiles(cipher[0])
				if err1 !=nil{
								msg:="ERROR: 404 Page Not Found!"
								 _, err2 := writer.Write([]byte(msg))
								 errEx(err2)
				 }else{
				fmt.Println("---------",request.Method)
				if request.Method=="GET"{
								data := Data{Password:request.FormValue("password"), Shift:shift}
								html.Execute(writer, data)
				}else{
							fmt.Println("value: ", request.FormValue("password"))
							encrypt := Cipher(request.FormValue("password"),shift,cipher[1])
							url := fmt.Sprintf("%s?password=%s&shift=%d",cipher[1],encrypt,shift)
							http.Redirect(writer, request,url,http.StatusFound)
					}
	}
	}
}

func Encrypt(writer http.ResponseWriter, request *http.Request){	
				cipher := []string{"1.html","/decrypt"}
				Handler(writer, request,cipher)
}

func Decrypt(writer http.ResponseWriter, request *http.Request){
				cipher := []string{"2.html","/encrypt"}
				Handler(writer, request,cipher)
}


func main(){
				fmt.Println("Hello World")
				http.HandleFunc("/encrypt",Encrypt)
				http.HandleFunc("/decrypt",Decrypt)
				err := http.ListenAndServe("localhost:5000",nil)
				errEx(err)
}
